﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;
using Hydac123;

namespace Hydac123Tests
{
    [TestClass]
    public class GuestLogSimpleTests
    {
        [TestMethod]
        public void AddGuest_WritesPromptsToConsole()
        {
            // Arrange
            var guestLog = new GuestLog();

            // Simuler brugerinput
            var input = new StringReader("TestNavn\nTestFirma\nTestAnsvarlig\n13:00\nA1\nJa\n");
            Console.SetIn(input);

            // Fang konsoloutput
            var output = new StringWriter();
            Console.SetOut(output);

            // Act
            guestLog.AddGuest();

            // Assert: Tjek om nogle af promptene blev skrevet
            var result = output.ToString();
            Assert.IsTrue(result.Contains("Navn:"));
            Assert.IsTrue(result.Contains("Firma:"));
        }
    }
}